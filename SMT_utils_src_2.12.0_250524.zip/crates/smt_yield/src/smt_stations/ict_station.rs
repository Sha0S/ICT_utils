#[derive(Debug, Default)]
pub struct IctStation {}
