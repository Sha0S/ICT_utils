#[derive(Debug, Default)]
pub struct FctStation {}
