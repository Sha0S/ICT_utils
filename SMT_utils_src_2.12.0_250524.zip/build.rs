extern crate embed_resource;

fn main() {
    embed_resource::compile("SMT_utils.rc", embed_resource::NONE);
}
